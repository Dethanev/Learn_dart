void main() {
  /*  !取反   */

  bool flag = false;

  print(flag); //false
  print(!flag); //true

  // /* &&並且:全部為true的話值為true 否則值為false */

  // bool a = true;
  // bool b = false;

  // print(a && b); //false

  // bool x = true;
  // bool y = true;

  // print(x && y); //true

  /* ||或者: 全為false的話值為false 否則值為true */

  // bool a = false;
  // bool b = false;

  // print(a || b); //false

  // bool x = true;
  // bool y = false;

  // print(x || y); //true

  // bool c = true;
  // bool d = true;

  // print(c || d); //true

  //如果一個人的年齡是20 並且 sex是女的話我們打印這個人

  // int age = 30;
  // String sex = '女';

  // if (age == 20 && sex == '女') {
  //   print("$age-----$sex");
  // } else {
  //   print("不輸出"); //輸出
  // }

  //如果一個人的年齡是20 或者 sex是女的話我們打印這個人

  // int age = 30;
  // String sex = '女';

  // if (age == 20 || sex == '女') {
  //   print("$age-----$sex"); //輸出
  // } else {
  //   print("不輸出");
  // }
}
