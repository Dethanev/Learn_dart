/* 布林值bool 的用法*/

//true可以等於0
//false可以等於1

void main() {
  bool flag1 = true; 
  bool flag2 = false;

  print(1 < 2); //true

  if (1 > 2) {
    print(flag1);
  } else {
    print(flag2); //false
  }
}
