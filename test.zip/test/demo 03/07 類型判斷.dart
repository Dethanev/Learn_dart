/*
Dart 判斷數據類型

is 關鍵字來判斷類型
*/

void main() {
  // var str1 = "1234";

  // if (str1 is String) {  //dart 編輯器覺得是廢話 所以黃色 因為你已經宣告過是字串了
  //   print('是string 類型'); //是string 類型
  // } else if (str1 is int) {
  //   print('int 類型');
  // } else {
  //   print("其他類型");
  // }

  // var str2 = 1234;

  // if (str2 is String) {
  //   print('是string 類型');
  // } else if (str2 is int) { //dart 編輯器覺得是廢話 所以黃色 因為你已經宣告過是字串了
  //   print('int 類型');  //int 類型
  // } else {
  //   print("其他類型");
  // }
}
