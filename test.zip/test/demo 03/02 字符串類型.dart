// 字串宣告 用法+$字串的拼接

void main() {
  String str1 = 'Hello';
  String str2 = 'World!';

  print(str1 + " " + str2); //Hello World!

  String str = "Hello World!";
  print("$str\n$str");
  // Hello World!
  // Hello World!
}
