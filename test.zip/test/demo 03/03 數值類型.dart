// 數值的宣告

void main() {
  int a = 20;
  double b = 30.0;

  print(a + b); // 運算符號+
}
