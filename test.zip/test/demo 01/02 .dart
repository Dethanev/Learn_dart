void main() {
  print("Hello World!");
}

/*
1. 上面的 main 是一個函數，是程式的入口函數，程序啟動，會從這裡開始執行;

2. void 表示函數是沒有返回值的，返回值是可以省略的;

3. print("Hello World"); 表示將字串 「Hello World」 列印到螢幕上。

4. 每行語句必須使用分號結尾，很多語言並不需要分號，比如 Swift、JavaScript;
*/ 
