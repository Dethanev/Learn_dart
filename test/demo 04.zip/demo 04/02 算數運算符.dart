void main() {
  int a = 13;
  int b = 5;

  print(a + b); //加 |18
  print(a - b); //減 |8
  print(a * b); //乘 |65
  print(a / b); //除 |2.6
  print(a % b); //取餘 |3
  print(a ~/ b); //取整 |2

  var c = a * b;

  print("---------");
  print(c); //65
}
